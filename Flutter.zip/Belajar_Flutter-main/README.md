# aplikasi_flutter_pertamaku.

Program ini dibuat untuk mata kuliah Pemrograman Mobile 2 

## Hasil Running

# Data Produk
![Gambar1](Screnshoot/dataproduk.png)

# Detail Produk
![Gambar2](Screnshoot/detailproduk.png)

### TERIMAKASIH

